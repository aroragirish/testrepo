import React, { Component } from 'react';
import Comment from './Comment';

interface comment {
    id: string,
    text: string
}

interface stateInterface {
    comments: Array<comment>
}

class Comments extends Component<Object, stateInterface> {
    constructor(props) {
      super(props)
      this.state = {
          comments: []
      }
    }

    componentDidMount() {
        this.getAllCommentsFromApi().then((res) => {
                res.json().then( data => {
                    this.setState({
                        comments: data
                    });
                });
            });
    }


    private getAllCommentsFromApi = () => {
        return fetch('/api/comments/', {
          method: 'get'
        });
      }

    private deleteComment = (id) => {
        return fetch(`/api/comments/${id}`, {
            method: 'delete'
          }).then(() => {
            this.getAllCommentsFromApi().then((res) => {
                res.json().then( data => {
                    this.setState({
                        comments: data
                    });
                });
            });
          })
    } 

    private getAllComments = () => {
        const {comments} = this.state;
        return (
            <ul>
                {comments.map((comment) => {
                    return <li key={comment.id}>
                        <Comment 
                            text={comment.text} 
                            id={comment.id}
                            deleteComment={this.deleteComment} />
                    </li>
                })}
            </ul>
        )
    }
    
    render() {
        return (
            <div>
                {this.getAllComments()}
            </div>
        )
    }
}

export default Comments;
