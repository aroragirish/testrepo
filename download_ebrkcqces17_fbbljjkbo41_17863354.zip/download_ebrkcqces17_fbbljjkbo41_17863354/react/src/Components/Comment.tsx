import React, { Component } from 'react'

const Comment = ({text, id, deleteComment}) => {
    return (
        <div onClick={() => deleteComment(id)}>
            <span>
                {text}
            </span>
            <button value="Delete" />
        </div>
    )
}

export default Comment;
