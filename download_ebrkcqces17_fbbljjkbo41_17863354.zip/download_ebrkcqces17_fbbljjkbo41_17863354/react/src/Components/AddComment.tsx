import React, { Component, useState } from 'react'

const AddComment = ({submitComment}) => {
    const [comment, setComment] = useState('');

    const updateComment = (event) => {
        setComment(event.target.value);
    }

    return (
        <div>
            <input placeholder="Add your comments..." value={comment} onChange={(event) => updateComment(event)} type="text"/>
            <input type="button" value="Submit" onClick={submitComment} />
        </div>
    )
}

export default AddComment;